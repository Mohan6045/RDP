package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.Wrapperclass;

public class Home extends Wrapperclass {
	WebDriver driver;
	public Home(WebDriver driver) {
		this.driver=driver;
	}
	 
	//elements location in web page
	By cat=By.xpath("//a[@href='https://www.marshallspetzone.com/14-Cat']");
	By search=By.xpath("//div[@class='st-search-bar for-desktop']//input");
	//click on cat button
	public void clickOnCat() {
		clickOnElement(driver, cat);
	}
	//click on search button 
	public void clickOnSearchButton() {
		clickOnElement(driver, search);
	}
	//get title
	public String getTitle() {
		return driver.getTitle();
	}
}
