package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.Wrapperclass;

public class Accessories extends Wrapperclass {
	WebDriver driver;
	public Accessories(WebDriver driver) {
		this.driver=driver;
	}
	 
	//elements location in web page
	By accessories=By.xpath("//div[@class='category-top-menu block-content']/ul/li[5]/a");
	By sortButton=By.xpath("//div[@class='products-sort-nb-dropdown products-sort-order dropdown']");
	By lowToHighPrice=By.xpath("//div[@class='row align-items-center justify-content-between small-gutters']/div[3]/div[1]/div/a[4]");
	By firstItemName=By.xpath("//div[@class='products row products-grid']/div[1]//h3");
	By listView=By.xpath("//a[@class=' js-search-link']");
	By homeLogo=By.xpath("//div[@id='desktop_logo']//a[1]");
    
	//click on accessories button 
	public void clickOnAccessories() {
		clickOnElement(driver, accessories);
	}
	//click on sort button
	public void clickOnSortButton() {
		clickOnElement(driver, sortButton);
	}
	//set low to high price
	public void clickOnLowToHighPrice() {
		clickOnElement(driver, lowToHighPrice);
		
	}
	//get string of name
	public String getFirstName() {
		return getTextFromElement(driver, firstItemName);
	}
	//click on list view
	public void clickOnListView() {
		
		clickOnElement(driver, listView);
		
		
	}
	//click on home button
	public void clickOnHomeLogo() {
		
		
		clickOnElement(driver, homeLogo);
	}
	//get title of page
	public String getTitle() {
		return driver.getTitle();
	}
	
	
}
