package testcases;

import org.testng.annotations.Test;


import pages.Accessories;

import pages.Home;

import utility.Wrapperclass;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class PetTestCase1 extends Wrapperclass{
	
	WebDriver driver;
	
	
	Home homePage;
	Accessories accessoriesPage;
	
	String Item="Pawzone Anti-Slip Spliced Flooring For Pets";
	String homePageTitle="Buy pet food Online Shop";
	String accPageTitle="Buy Cat Products Online India";
	
 
	 @BeforeClass
	 @Parameters("browser")
	  public void beforeClass(String browser) {
		  
		 driver= launchBrowser(browser,"https://www.marshallspetzone.com/");
	  }
  
	 @Test(priority=0)
     public void setHomePage() {
     	//set driver home page
     	homePage=new Home(driver);
     	//get title of page
     	String eTitle=homePage.getTitle();
     	//click on cat button
     	homePage.clickOnCat();
     	//check assert of title
     	Assert.assertTrue(eTitle.contains(homePageTitle));    
	    }
	 
	 
	 @Test(priority=1)
     public void itemSearchTest() throws InterruptedException {
     	//set driver for page
     	accessoriesPage=new Accessories(driver);
     	//get title of apge
     	String eTitle=accessoriesPage.getTitle();
     	//click on accessories 
     	accessoriesPage.clickOnAccessories();
     	//click on sort button
     	accessoriesPage.clickOnSortButton();
     	//set low to high price
     	accessoriesPage.clickOnLowToHighPrice();
     	//get first item
     	String firstItem=accessoriesPage.getFirstName();
     	//write in excel sheet 
     	writeExcel("src\\test\\resources\\TESTDATA\\petshop.xlsx", "Sheet1",1, 0,firstItem);
     	Thread.sleep(3000);
     	// click on list view from grid view
     	accessoriesPage.clickOnListView();
     	Thread.sleep(5000);
     	
     	//take screen shot of page
     	takeScreenShot();
     	//click on home button
     	Thread.sleep(5000);
     	accessoriesPage.clickOnHomeLogo();
     	homePage=new Home(driver);
     	//click on search button 
     	homePage.clickOnSearchButton();
     	//check assert on title
     	Assert.assertTrue(eTitle.contains(accPageTitle));

     	//a[@class=' js-search-link']
     }

	 
  

  @AfterClass
  public void afterclass() {
	  
	  
	  driver.close();
  }

}
