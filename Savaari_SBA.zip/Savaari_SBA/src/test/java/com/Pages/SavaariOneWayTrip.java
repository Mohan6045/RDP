package com.Pages;

import java.time.LocalDate;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import Com.BaseClass.Action;

public class SavaariOneWayTrip 
{
	WebDriver driver;
	//xpath for oneWayTrip
	By oneWayTrip = By.xpath("//label[@for='oneway_radio']");
	//xpath for from location
	By fromLocation = By.xpath("//input[@id='fromCityList']");
	//xpath for to location
	By toLocation = By.xpath("//div[@class='col-10 col tocityHolder']//input");
	//xpath to click calender
	By selectDate = By.xpath("//div[@class='input fromDatePick']//input");  
	//xpath to pick date from the calender
	By pickdatetable=By.xpath("//div[@class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all ui-shadow ng-trigger ng-trigger-overlayState']//table//tbody//a[@class='ui-state-default ng-tns-c11-1']");
	//xpath to select time
	By selectTime = By.xpath("//select[@id='pickUpTime']");
	//xpath to click select car button
	By selectCar = By.xpath("//button[@class='book-button btn']");
	Action action = new Action();
	//initializing constructor
	public SavaariOneWayTrip(WebDriver driver)
	{
		this.driver = driver;
	}
	//method to select one way radio button
	public void oneWaytrip()
	{
		driver.findElement(oneWayTrip).click();
	}
	//method to enter data into from loaction text box using excel
	public void fromLocation(String fromcity) throws InterruptedException
	{
		driver.findElement(fromLocation).sendKeys(fromcity);
		Thread.sleep(2000);
		action.actions(driver);
	}
	//method to enter data into to loaction text box using excel
	public void toLocation(String tocity) throws InterruptedException
	{
		driver.findElement(toLocation).sendKeys(tocity);
		Thread.sleep(3000);
		action.actions(driver);
	}
	//method to select date from calender
	public void selectDate() throws InterruptedException
	{	
		driver.findElement(selectDate).click();
		Thread.sleep(2000);
		String nextDate=getFutureDate(1);
		Thread.sleep(2000);
		setDate(nextDate);
	}
	//method to select time from drop down
	public void selectTime()
	{
		WebElement wb=driver.findElement(selectTime);
		Select DD=new Select(wb);
		DD.selectByVisibleText("4:15 PM"); 	
	}
	//method to click select car button
	public void selectCar()
	{
		driver.findElement(selectCar).click();
	}
	
	//set date selection in both depature and return 
		public void setDate(String daySet) {
//		     elementclick( driver,dateDeparture,20).click();
			try {	Thread.sleep(5000);	} catch (InterruptedException e) {	e.printStackTrace();}
		     //list of all date in table
	        List <WebElement> listElements= driver.findElements(pickdatetable);
	        //get next Wednesday
	        String day=daySet;
	    
			for (WebElement element:listElements)
			{
				//check with given date
				String getDay=element.getText();
				if(getDay.equalsIgnoreCase(day))
				{
					//if date is found then click on that date
					element.click();
					break;
				}
			}
		}
		
		//select date
		public String getFutureDate(int addDay) {
			//set object local date 
			LocalDate dt = LocalDate.now();
			
			//get int of day
			int intDay=dt.getDayOfMonth()+addDay;
			//convert to string
			String day=Integer.toString(intDay);
			return day;
		}
}
