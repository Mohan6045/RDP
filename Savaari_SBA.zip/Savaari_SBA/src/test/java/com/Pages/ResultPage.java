package com.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ResultPage {
	
	WebDriver driver;
	//Xpath for second car 
	By carname = By.xpath("//div[@class='rateUIDesktop carListContent7 row carListContent carListBlock']//child::div[@class='row carNamesDesktop']//child::span[1]");
	//initializing constructor
	public ResultPage(WebDriver driver)
	{
		this.driver= driver;
	}
	//method to extract second car name from results page
	public String secondCarName()
	{
		String carname2=driver.findElement(carname).getText();
		return carname2;
	}
}
