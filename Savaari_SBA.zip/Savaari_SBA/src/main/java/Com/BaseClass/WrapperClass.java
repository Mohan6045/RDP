package Com.BaseClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class WrapperClass {
	WebDriver driver;

	public WebDriver launchBrowser(String browser,String URL) throws InterruptedException
	{
		if(browser.equalsIgnoreCase("Chrome"))   // Check if parameter passed as 'chrome'
		{
			System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\Drivers\\chromedriver.exe"); //set path to chromedriver.exe
			//creating object in Chromeoptions
			ChromeOptions option=new ChromeOptions();
			//disable notification in chrome 
			option.addArguments("--disable-notifications");
			//create chrome instance
			driver=new ChromeDriver(option);
		}
		//check if parameter passed as 'edge'
		else if(browser.equalsIgnoreCase("EDGE")) {
			//set path to msedgedriver.exe
			System.setProperty("webdriver.edge.driver", "src\\test\\resources\\Drivers\\msedgedriver.exe");
			//create object for option in edge
			EdgeOptions options=new EdgeOptions();
			//disable notification in edge
			options.setCapability("--disable-notifications", true);
			//create edge instance
			driver=new EdgeDriver(options);

		}else {
			System.out.println("Please Enter right browser name");
		}
		// gets url
		driver.get(URL); 
		//it maximize size of browser
		driver.manage().window().maximize();
		//delete all cookies present on history of page
		driver.manage().deleteAllCookies();
		//set implicit wait in driver
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//			// set page load time
		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);

		return driver;
	}
	public void closeBrowser()
	{
		driver.close();
	}

}


