package Com.BaseClass;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class Action 
{
	//Action to perform enter option using key board
	public void actions(WebDriver driver)
	{
	Actions action = new Actions(driver);
	action.sendKeys(Keys.ENTER).build().perform();
	}
}
