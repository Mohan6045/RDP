package pages;

import java.time.LocalDate;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utility.Wrapperclass;

public class Home extends Wrapperclass{

	WebDriver driver;
	public Home(WebDriver driver) {
		this.driver=driver;
	}
	 
	//elements location in web page
	By fromCity=By.id("src");
	By fromCitySelect=By.xpath("//div[@class='fl search-box clearfix']/div/ul/li[1]");
    By toCity=By.id("dest");
	By toCitySelect=By.xpath("//div[@class='fl search-box']/div/ul/li[1]");
	By dateButton=By.xpath("//div[@class='fl search-box date-box gtm-onwardCalendar']");
	By dayTable=By.xpath("//div[@id='rb-calendar_onward_cal']/table//child::td");
	By searchButton=By.id("search_btn");
	
	//set from city with given name
	public void setFromCity(String city) {
		sendTextToElement(driver, fromCity, city);
		clickOnElement(driver, fromCitySelect);
	}
	
	//set to city with given name
	public void setToCity(String city) {
		sendTextToElement(driver, toCity, city);
		clickOnElement(driver, toCitySelect);
	}
	
	//click on search button 
	public void clickOnSearchButton() {
		clickOnElement(driver, searchButton);
	}
	
	//select future date 
	public void selectDateOnward() {
		clickOnElement(driver, dateButton);
		String day=getFutureDate(5);
		setDate(day);
	}
	
	//set function search bus with given detail
	public void setSearchFunction(String fromCityName,String toCityName) {
		setFromCity(fromCityName);//set from city
		setToCity(toCityName);//set to city
		selectDateOnward();//select date 
		clickOnSearchButton();//click on search button
	}
	
	//set date selection in both departure and return 
		public void setDate(String daySet) {
		     //list of all date in table
	        List <WebElement> listElements= driver.findElements(dayTable);
	        //get next Wednesday
	        String day=daySet;
	    
			for (WebElement element:listElements)
			{
				//check with given date
				String getDay=element.getText();
				if(getDay.equalsIgnoreCase(day))
				{
					//if date is found then click on that date
					element.click();
					break;
				}
			}
		}
		
		//select date
		public String getFutureDate(int addDay) {
			//set object local date 
			LocalDate dt = LocalDate.now();
			
			//get int of day
			int intDay=dt.getDayOfMonth()+addDay;
			//convert to string
			String day=Integer.toString(intDay);
			return day;
		}
	
	
	//get title of page
	public String getTitle() {
		return driver.getTitle();
	}

}
