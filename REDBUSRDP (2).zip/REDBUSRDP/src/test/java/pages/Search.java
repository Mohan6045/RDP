package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.Wrapperclass;

public class Search  extends Wrapperclass{
	WebDriver driver;
	public Search(WebDriver driver) {
		this.driver=driver;
	}
	 
	//elements location in web page
	//By closeWidge=By.xpath("//div[@class='close']");
	By nonAcCheckBox=By.xpath("//div[@class='details']/ul[3]/li[3]/label[1]");
	By nameOfSecondBus=By.xpath("//ul[@class='bus-items']/div[2]/li/div/div[1]/div[1]/div[1]/div[1]");
	By priceOfSecondBus=By.xpath("//ul[@class='bus-items']/div[2]/li/div/div[1]/div[1]/div[6]/div/div[2]/span");
	
//	//click on widge 
//	public void clickOnWidge() {
//		clickOnElement(driver, closeWidge);
//	}
	
	
	//click on Non AC checkbox
	public void clickOnNonACBus() {
		clickOnElement(driver, nonAcCheckBox);
	}
	
	//get name of bus
	public String getNameOfBus() {
		return getTextFromElement(driver, nameOfSecondBus);
	}
	
	//get price detail of bus
	public String getPriceOfBus() {
		return getTextFromElement(driver, priceOfSecondBus);
	}
	
	//set function of getting name and price
	public String getPriceandNameOfBus() {
		//clickOnWidge();
		clickOnNonACBus();
		//get name string 
		String name=getNameOfBus();
		//get price string 
		String price=getPriceOfBus();
		//return detail of bus
		return "Name Bus is : "+name+" and Price of Bus is :"+price;
	}
	
	//get title of page
		public String getTitle() {
			return driver.getTitle();
		}
	
	

}
