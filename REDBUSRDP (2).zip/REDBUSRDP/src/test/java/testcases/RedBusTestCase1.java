package testcases;

import org.testng.annotations.Test;

import pages.Home;
import pages.Search;
import utility.Wrapperclass;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class RedBusTestCase1 extends Wrapperclass{
	
	WebDriver driver;
	
	
	Home homePage;
	Search searchPage;
	
	String homePageTitle="Book Bus Travels";
	String searchPageTitle="Search Bus Tickets";

	//get detail of city from excel sheet
	String fromCity=readExcel("src\\test\\resources\\TESTDATA\\RedBusData.xlsx", "Sheet1", 1, 0);
	String toCity=readExcel("src\\test\\resources\\TESTDATA\\RedBusData.xlsx", "Sheet1",1, 1);
 
	 @BeforeClass
	@Parameters("browser")
	  public void beforeClass(String browser ) {
		
		 driver= launchBrowser(browser,"https://www.redbus.in/");
	  }
  
	 @Test(priority=0)
     public void busSearch() {
	         //driver set home page
	         homePage=new Home(driver);
	         //get title of home page
	         String eTitle= homePage.getTitle();
	         //search of bus with enter parameter like city and date
	         homePage.setSearchFunction(fromCity, toCity);
	        //check assert of page title
	         Assert.assertTrue(eTitle.contains(homePageTitle));
	   }
     @Test(priority=1)
     public void printNameAndPrice() {
	         //driver set search page
     		searchPage=new Search(driver);
	         //get title of search page
	         String eTitle= searchPage.getTitle();
	         //due to technical reason of website AC checkbox is not available in page 
	         // Non AC checkbox option is working
	         
	         //get detail of bus and set non AC type
	         String busDetail=searchPage.getPriceandNameOfBus();
	         //take screen shot of page 
	         takeScreenShot();
	         //print bus name and price
	         System.out.println(busDetail);
	        //check assert of page title
	         Assert.assertTrue(eTitle.contains(searchPageTitle));
	   }
     
  

  @AfterClass
  public void afterClass() {
	  
	  
	  driver.close();
  }

}
