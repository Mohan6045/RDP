package Pages;

import java.awt.AWTException;
import java.awt.Robot;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import Base_Class.WrapperClass;

public class FdCalculatorPage extends WrapperClass {
	WebDriver driver;
	
	public FdCalculatorPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void SelectSeniorCitizen() {
		
		 driver.findElement(By.xpath("//label[@for='radio2']")).click();
	}
	
	public void SelectMonthlyPayout()
	{
		driver.findElement(By.xpath("//select[@id='FdepType']//option[@value='Monthly Payout']")).click(); 
	}
	
	public void Enter40000()
	{
		  int number = readexcel("src\\test\\resources\\Data_Sheet\\axisbank_excel.xlsx","Sheet1",0,0);
		  driver.findElement(By.xpath("//input[@class='inpt inputBox numbersOnly loanAmt']")).clear();
		  
		  driver.findElement(By.xpath("//input[@class='inpt inputBox numbersOnly loanAmt']")).sendKeys(String.valueOf(number));
	}
	
	public void ClickAnywhere() throws AWTException
	{
		 Actions actions = new Actions(driver);

		  Robot robot = new Robot();

		  robot.mouseMove(50,50);

		  actions.click().build().perform();
	}
	public void PrintRateOfInterest()
	{
		 String s =driver.findElement(By.xpath("//span[@class='idRate pull-right']")).getText();
		 System.out.println(s);
	}
	
	

}
