package TestCases;

import org.testng.annotations.Test;

import Base_Class.WrapperClass;
import Pages.FdCalculatorPage;

import org.testng.annotations.BeforeMethod;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;

public class NewTest extends WrapperClass{
	WebDriver driver;
  
  @BeforeMethod
  public void beforeMethod() {
	  
	 driver= LaunchBrowser("Firefox","https://www.axisbank.com/retail/calculators/fd-calculator");
  }
  
  @Test
  public void Testcase() throws AWTException{
	  
	  FdCalculatorPage FCP = new FdCalculatorPage(driver);
	  FCP.SelectSeniorCitizen();
	  
	  FCP.SelectMonthlyPayout();
	  
	  FCP.Enter40000();
	  
	  FCP.ClickAnywhere();
	  
	  FCP.PrintRateOfInterest();
	  
	  TakeScreenShot();
	  
	    
	  
  } @AfterMethod
  public void afterMethod() {
	  
	 driver.close();
  }
  

}
