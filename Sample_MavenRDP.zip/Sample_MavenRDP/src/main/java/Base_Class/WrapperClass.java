package Base_Class;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WrapperClass {
WebDriver driver;
static int counter=0;
	public WebDriver LaunchBrowser(String browser,String URL)
	{
		if(browser=="Chrome")
		{
			System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\Driver\\chromedriver.exe");
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("profile.default_content_setting_values.notifications", 2);			
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", prefs);
			driver = new ChromeDriver(options);
		}
		else if(browser=="Firefox")
		{
			
//			FirefoxProfile profile = new FirefoxProfile();
//			profile.setPreference(�permissions.default.desktop-notification�, 1);
//			DesiredCapabilities capabilities=DesiredCapabilities.firefox();
//			capabilities.setCapability(FirefoxDriver.PROFILE, profile);
//			driver = new FirefoxDriver(capabilities);
			
			
			
			
			
			System.setProperty("webdriver.gecko.driver", "src\\test\\resources\\Driver\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		driver.get(URL); 
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
		
		
		return driver;
	}
	
	public static int readexcel(String filename,String Sheet,int r,int c)
	{
		int s=0;
		try {
			File f=new File(filename);
			FileInputStream fin= new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fin);
			XSSFSheet sh= wb.getSheet(Sheet);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell =row.getCell(c);
			s= (int) cell.getNumericCellValue();
			} catch (FileNotFoundException e) {
		
				e.printStackTrace();
			} catch (IOException e) {
		
				e.printStackTrace();
			}
		return s;
	}
	
	
	public void TakeScreenShot() {
		
		String path="src\\test\\resources\\ScreenShot\\";              //  Setting File Path  to store the ScreenShots
		String filename=counter+".png";
		
		File f1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);		
		 File f2= new File(path+filename);
		 try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		 counter++;
	}
	
}
