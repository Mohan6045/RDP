package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.Wrapperclass;

public class Home extends Wrapperclass{
	
	WebDriver driver;
	
	
	By logo=By.xpath("//body/div[1]/div[3]/div[1]/div[2]/a[1]");
	
	public Home(WebDriver driver)
	{
		this.driver=driver;
		
	}

	public void logoClick()
	{
		clickOnElement(driver,logo);
	}
	
	
}
