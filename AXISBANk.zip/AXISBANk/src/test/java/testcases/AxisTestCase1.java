package testcases;

import org.testng.annotations.Test;

import pages.FdCalculatorPage;
import utility.Wrapperclass;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class AxisTestCase1 extends Wrapperclass{
	
	WebDriver driver;
 
	 @BeforeMethod
	 @Parameters("browser")
	  public void beforeMethod(String browser) {
		  
		 driver= launchBrowser(browser,"https://www.axisbank.com/retail/calculators/fd-calculator");
	  }
  
  @Test
  public void test() throws AWTException {
	  
	  FdCalculatorPage calculator = new FdCalculatorPage(driver);
	  
	  calculator.selectSeniorCitizen();  // click on  senior radio button
	  
	  calculator.selectMonthlyPayout();   // selecting monthly payouts
	  
	  calculator.enterValue();            // entering the value
	  
	  calculator.clickAnywhere();          // clicking anywhere on screen
	  
	  calculator.printRateOfInterest();    // printing rate of interest
	  
	
	  takeScreenShot();
	  
  }
  

  @AfterMethod
  public void afterMethod() {
	  
	  
	  driver.close();
  }

}
