package pages;

import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import utility.Wrapperclass;

public class FdCalculatorPage extends Wrapperclass{

	WebDriver driver;
	
	By senior_button= By.xpath("//label[@for='radio2']");   // selecting senior citizen radio button
	
	By monthly_payouts= By.xpath("//select[@id='FdepType']//option[@value='Monthly Payout']"); 
	
	By amount= By.xpath("//input[@class='inpt inputBox numbersOnly loanAmt']");
	
	By rate_of_interest=By.xpath("//span[@class='idRate pull-right']");
	
	public FdCalculatorPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void selectSeniorCitizen() {
		
		 clickOnElement(driver, senior_button);
	}
	
	public void selectMonthlyPayout()
	{
		clickOnElement(driver, monthly_payouts);
	}
	
	public void enterValue()
	{
		  int number = readExcel("src\\test\\resources\\TESTDATA\\axisbank_excel.xlsx","Sheet1",0,0);
		  driver.findElement(By.xpath("//input[@class='inpt inputBox numbersOnly loanAmt']")).clear();
		  
		  sendTextToElement(driver,amount,(String.valueOf(number)));
	}
	
	public void clickAnywhere() throws AWTException
	{
		 Actions actions = new Actions(driver);

		  Robot robot = new Robot();

		  robot.mouseMove(50,50);

		  actions.click().build().perform();
	}
	public void printRateOfInterest()
	{
		 String s =getTextFromElement(driver,rate_of_interest);
		 System.out.println(s);
	}
	
	
	
}
