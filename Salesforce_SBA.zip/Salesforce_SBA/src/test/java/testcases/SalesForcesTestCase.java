package testcases;

import org.testng.annotations.Test;

import pages.Home;
import pages.LogIn;
import pages.SignUpPage;
import utility.Wrapperclass;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class SalesForcesTestCase extends Wrapperclass {
	WebDriver driver;
	
	Home home;
	
	SignUpPage signup;
	
	LogIn login;
	
 
  @BeforeClass
  @Parameters("browser")
  public void launchBrowser(String browser ) throws InterruptedException {
	  
	  driver= launchBrowser(browser,"https://developer.salesforce.com/");  // launching the browser 
  }
  
  
  
  @Test
  public void testCase() throws AWTException, InterruptedException {
	  
	  home= new Home(driver);    // object  creation of home
	  signup = new SignUpPage(driver);  // object  creation of signup
	  login = new LogIn(driver); // object  creation of LogIn
	  
	  home.signUp();          // navigates to signup
	  
	  signup.emailId();      // navigates to emailId
	  
	  String errormessage= signup.errorMessage();      // gets the errormessage
	  System.out.println(errormessage);
	  
	  signup.selectCountry();                   // navigates to selectCountry
	  
	  signup.logIn();                           // navigates to logIn       
	  
	  login.checkRememberMe();                  //navigates to checkRememberMe
	  
	  takeScreenShot();             // taking the screenshot
	  
  }
  
  
  @AfterClass
  public void closeBrowser() {
        //close current browser
        driver.close();
  }



}
