package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.Wrapperclass;

public class LogIn extends Wrapperclass{
	
	WebDriver driver;
	
	
	By remember=By.xpath("//input[@name='rememberUn']");  // xpath for remember
	
	public LogIn(WebDriver driver)
	{
		this.driver=driver;
		
	}
	
	// clicking on checkbox remember me

	public void checkRememberMe()
	{
		clickOnElement(driver,remember);
	}
	
	
}
