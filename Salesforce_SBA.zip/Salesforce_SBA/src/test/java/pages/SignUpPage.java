package pages;

import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import utility.Wrapperclass;

public class SignUpPage extends Wrapperclass{

	WebDriver driver;
	
	
	By email=By.xpath("//input[@id='email']");   // xpath for email
	
	By error=By.xpath("//div[@class='errorContainer']");         // xpath for error
	
	By country=By.xpath("//select[@id='country']");               // xpath for country
	
	By login=By.xpath("//a[@href='/forums/CommunitiesLogin?startURL=%2F']");         // xpath for login
	
   
    
	
	public SignUpPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void emailId() throws InterruptedException
	{
		String emailvalue=readExcelString("src\\test\\resources\\TESTDATA\\sales_Data.xlsx","Sheet1",1,0); // reads the emailid from  Excel 
		
		sendTextToElement(driver,email,emailvalue);    // entering the email
		sendTextToElementAction(driver,email,Keys.TAB);  // entering the tab button in button
		
	}
	
	
	public String errorMessage() {
		
		String errormessage=getTextFromElement(driver,error);    // gets the data error message
		
		return errormessage;
	}
	
	
	public void selectCountry() {
		
		// reads the country name from excel
		String countryname=readExcelString("src\\test\\resources\\TESTDATA\\sales_Data.xlsx","Sheet1",1,1); 
		
		WebElement wb=driver.findElement(By.xpath("//select[@id='country']"));        // select the select webElement
		Select DD=new Select(wb);
		DD.selectByVisibleText(countryname);   // select australia name in dropdown
	}
	
	
	
	public void logIn()
	{
		clickOnElement(driver,login);    // clicking the login button
	}
		
		
	
	}
	
	
	
	
	
	
