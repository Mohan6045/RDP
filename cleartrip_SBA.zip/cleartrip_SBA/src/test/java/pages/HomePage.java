package pages;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import utility.Wrapperclass;

public class HomePage extends Wrapperclass  {
	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}
	 
	//elements location in web page
	By roundTrip=By.id("RoundTrip");
	By fromCity=By.id("FromTag");
	By toCity=By.id("ToTag");
	By selectFromCity=By.xpath("//ul[@id='ui-id-1']/li[1]/a");
	By selectToCity=By.xpath("//ul[@id='ui-id-2']/li[1]/a");
	By departDate=By.id("DepartDate");
	By returnDate=By.id("ReturnDate");
	By departDateTable=By.xpath("//div[@id='ui-datepicker-div']//table//a");
	By selectAdult=By.id("Adults");
	By searchBtn=By.id("SearchBtn");
	By next=By.xpath("//div[@class='col-19']/div[2]/div[4]");
	
	//click on round trip radio button
	public void clickRoundTrip() {
		clickOnElement(driver,roundTrip);
	}
	
	//select from city in page
	public void selectFromCity() {
		driver.findElement(By.id("FromTag")).clear();
		
		String fromlocation=readExcel("src\\test\\resources\\TESTDATA\\cleartrip_Data.xlsx","Sheet1",1,0);
		
		sendTextToElement(driver, fromCity, fromlocation);
		clickOnElement(driver,fromCity);
		
	}
	//select to city in page
	public void selectToCity() {
		driver.findElement(By.id("ToTag")).clear();
		String tolocation=readExcel("src\\test\\resources\\TESTDATA\\cleartrip_Data.xlsx","Sheet1",1,1);
		sendTextToElement(driver, toCity, tolocation);
		clickOnElement(driver,toCity);
		
	}
	
	//select departure date in page
	public void selectDepatureDate(int day) {
		clickOnElement(driver,departDate);
		String nextDate=getFutureDate(day);
		setDate(nextDate);
	}
	
	//select return date in page
	public void selectReturneDate(int day) {
		clickOnElement(driver,returnDate);
		String nextDate=getFutureDate(day);
		setDate(nextDate);
	}
	
	//select 2 adult in page
	public void selectAdultNum() {
		WebElement we=driver.findElement(By.id("Adults"));
		Select s=new Select(we);
		s.selectByVisibleText("2");
	}
	
	//click on search page
	public void clickOnSearch() {
		clickOnElement(driver,searchBtn);
		
	}
	
//	public void clickonNext() {
//		elementclick(driver, next, 30).click();
//	}
	
	
	//set function for flight booking 
	public void SetFlightSearch() {
		clickRoundTrip();
		selectFromCity();
		selectToCity();
		selectDepatureDate(5);
		selectReturneDate(8);
		selectAdultNum();
		clickOnSearch();
		//clickonNext();
		
	}
	
	
	
	
	//get title of pahe
	public String getTitle() {
		return driver.getTitle();
	}
	
	//set date selection in both depature and return 
	public void setDate(String daySet) {
//	     elementclick( driver,dateDeparture,20).click();
		try {	Thread.sleep(5000);	} catch (InterruptedException e) {	e.printStackTrace();}
	     //list of all date in table
        List <WebElement> listElements= driver.findElements(departDateTable);
        //get next Wednesday
        String day=daySet;
    
		for (WebElement element:listElements)
		{
			//check with given date
			String getDay=element.getText();
			if(getDay.equalsIgnoreCase(day))
			{
				//if date is found then click on that date
				element.click();
				break;
			}
		}
	}
	
	//select date
	public String getFutureDate(int addDay) {
		//set object local date 
		LocalDate dt = LocalDate.now();
		
		//get int of day
		int intDay=dt.getDayOfMonth()+addDay;
		//convert to string
		String day=Integer.toString(intDay);
		return day;
	}
	
	
}
