package pages;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import utility.Wrapperclass;

public class HomePage extends Wrapperclass  {
	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}
	 
	//elements location in web page
	By roundTrip=By.xpath("//input[@id='ctl00_mainContent_rbtnl_Trip_1']");
	By fromCity=By.xpath("//input[@name='ctl00_mainContent_ddl_originStation1_CTXT']");
	By toCity=By.xpath("//input[@name='ctl00_mainContent_ddl_destinationStation1_CTXT']");
	By departDate=By.xpath("//input[@name='ctl00$mainContent$view_date1']");
	By returnDate=By.xpath("//input[@name='ctl00$mainContent$view_date2']");
	By departDateTable=By.xpath("//div[@id='ui-datepicker-div']//table//a");
	By adultfield=By.xpath("//div[@id='divpaxinfo']");
	By selectAdult=By.xpath("//div[@class='row1 adult-infant-child']//child::p[1]//option[2]");
	By searchBtn=By.xpath("//input[@id='ctl00_mainContent_btn_FindFlights']");
	//By next=By.xpath("//div[@class='col-19']/div[2]/div[4]");
	
	//click on round trip radio button
	public void clickRoundTrip() {
		
		clickOnElement(driver,roundTrip);
	}
	
	//select from city in page
	public void selectFromCity() {
		driver.findElement(By.xpath("//input[@name='ctl00_mainContent_ddl_originStation1_CTXT']")).clear();
		
		String fromlocation=readExcel("src\\test\\resources\\TESTDATA\\SpiceJet_data.xlsx","Sheet1",1,0);
		
		sendTextToElement(driver, fromCity, fromlocation);
		clickOnElement(driver,fromCity);
		
	}
	//select to city in page
	public void selectToCity() {
		driver.findElement(By.xpath("//input[@name='ctl00_mainContent_ddl_destinationStation1_CTXT']")).clear();
		String tolocation=readExcel("src\\test\\resources\\TESTDATA\\SpiceJet_data.xlsx","Sheet1",1,1);
		sendTextToElement(driver, toCity, tolocation);
		clickOnElement(driver,toCity);
		
	}
	
	//select departure date in page
	public void selectDepatureDate(int day) {
		clickOnElement(driver,departDate);
		String nextDate=getFutureDate(day);
		setDate(nextDate);
	}
	
	//select return date in page
	public void selectReturneDate(int day) throws InterruptedException {
		clickOnElement(driver,returnDate);
		String nextDate=getFutureDate(day);
		setDate(nextDate);
		Thread.sleep(4000);
	}
	
	//select 2 adult in page
	public void selectAdultNum() {

		clickOnElement(driver,adultfield);
		
		clickOnElement(driver,selectAdult);
		
	}
	
	//click on search page
	public void clickOnSearch() {
		clickOnElement(driver,searchBtn);
		
	}
	
//	public void clickonNext() {
//		elementclick(driver, next, 30).click();
//	}
	
	
	//set function for flight booking 
	public void SetFlightSearch() throws InterruptedException {
		clickRoundTrip();
		selectFromCity();
		selectToCity();
		selectDepatureDate(6);
		selectReturneDate(9);
		selectAdultNum();
		clickOnSearch();
		//clickonNext();
		
	}
	
	
	
	
	//get title of pahe
	public String getTitle() {
		return driver.getTitle();
	}
	
	//set date selection in both depature and return 
	public void setDate(String daySet) {
//	     elementclick( driver,dateDeparture,20).click();
		try {	Thread.sleep(5000);	} catch (InterruptedException e) {	e.printStackTrace();}
	     //list of all date in table
        List <WebElement> listElements= driver.findElements(departDateTable);
        //System.out.println();
        //get next Wednesday
        String day=daySet;
    
		for (WebElement element:listElements)
		{
			//check with given date
			String getDay=element.getText();
			if(getDay.equalsIgnoreCase(day))
			{
				//if date is found then click on that date
				element.click();
				break;
			}
		}
	}
	
	//select date
	public String getFutureDate(int addDay) {
		//set object local date 
		LocalDate dt = LocalDate.now();
		
		//get int of day
		int intDay=dt.getDayOfMonth()+addDay;
		//convert to string
		String day=Integer.toString(intDay);
		return day;
	}
	
	
}
