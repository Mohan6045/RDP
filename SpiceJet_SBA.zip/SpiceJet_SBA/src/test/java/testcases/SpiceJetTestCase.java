package testcases;

import org.testng.annotations.Test;

import pages.HomePage;
import utility.Wrapperclass;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class SpiceJetTestCase extends Wrapperclass{
	
	HomePage homePage;
	WebDriver driver;
	
		
	//parameters set browser name in testng class
		@BeforeMethod
		@Parameters("browser")
		public void launchBrowsers(String browser) {
			//launch browser in given browser type
			driver=launchBrowser(browser,"https://www.spicejet.com/");
			
		}
        @Test
        public void flightBook() throws InterruptedException {
	         //driver set home page
	         homePage=new HomePage(driver);
	         // search flight
	         homePage.SetFlightSearch();
	         //take screen shot of page
	         Thread.sleep(6000);
	         takeScreenShot();
	        
	   }
 

       @AfterMethod
       public void closeBrowser() {
	        //close current browser
	        driver.close();
       }

}
